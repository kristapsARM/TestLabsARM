$script:modulesFolderPath = Split-Path -Path $PSScriptRoot -Parent
