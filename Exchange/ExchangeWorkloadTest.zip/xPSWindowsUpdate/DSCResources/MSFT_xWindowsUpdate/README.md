# Description

The resource is responsible for ensuring that a MSU
(Standalone Windows Update) is installed from a given path.

For more information around hotfixes, please refer to the article
[Best Practices for Applying Service Packs, Hotfixes and Security Patches](https://docs.microsoft.com/en-us/previous-versions/tn-archive/cc750077(v=technet.10)).
