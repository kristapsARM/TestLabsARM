---
name: Resource proposals
about: PSDscResources does not accept new resources! Please submit a new resource request to the appropriate DSC resource module repository.
---

This resource module does not accept new resources.
Please submit new resource requests to an appropriate DSC resource module
repository found in the [maintainers list](https://github.com/PowerShell/DscResources/blob/master/Maintainers.md)
in the [DSCResources repository](https://github.com/PowerShell/DscResources),
or to the [xPSDesiredStateConfiguration repository](https://github.com/PowerShell/xPSDesiredStateConfiguration).
