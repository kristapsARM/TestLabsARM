# Change log for xDownloadFile

## Unreleased

* Updated error handling to detect issues with download, preventing an endless loop.

## 1.0.0

* Initial public release of xDownloadFile
